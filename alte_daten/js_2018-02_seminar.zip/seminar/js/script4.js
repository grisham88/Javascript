/**
 * Created by j304830 on 27.01.15.
 */

console.log("Ähh. Ich bin Script 4. Ich werde ganz anders geholt!");
