/**
 * Created by j304830 on 27.01.15.
 */

console.log("Hey, ich bin Script 2");
